const urlParams = new URLSearchParams(window.location.search);

const min_temp = 0;
const max_temp = 30;

const charts_in_row = urlParams.has('cols') ? parseInt(urlParams.get('cols')) : 2;
const max_char_points = urlParams.has('points') ? parseInt(urlParams.get('points')) : 60;

// Total history span (seconds) each line chart covers, independent of
// max_char_points — points are filled by time-bucketing WS updates (see
// bucket_ms below) rather than one point per update, so a longer window
// doesn't cost more rendered points. Default 1800s (30 min) / 60 points =
// 30s/bucket. ?window=60 with the default point count reproduces the old
// one-point-per-second behavior exactly.
const window_seconds = urlParams.has('window') ? parseInt(urlParams.get('window')) : 1800;
const bucket_ms = Math.max(1, Math.round((window_seconds * 1000) / max_char_points));

const display_charts = urlParams.has('no_charts') ? false : true;

function format_timestamp(date) {
	return date.toLocaleDateString(navigator.language, {
		hour12: false
	}) + ' ' + date.toLocaleTimeString(navigator.language, {
		hour12: false
	});
}

function format_sec(sec) {
	sec = Number(sec);
	var d = Math.floor(sec / (3600 * 24));
	var h = Math.floor(sec % (3600 * 24) / 3600);
	var m = Math.floor(sec % 3600 / 60);
	var s = Math.floor(sec % 60);
	return [d > 0 ? d + 'd' : undefined, h > 0 ? h + 'h' : undefined, m > 0 ? m + 'm' : undefined, s > 0 ? s + 's' : undefined].filter( (p) => typeof p != 'undefined').join(' ');
}

var TIMEData = function(data) {
	var elm = document.querySelector('[data-id="TIME"]');
	if (elm) {
		var now = new Date();
		var date = new Date(data * 1000);
		var diff = ((now > date) ? (now - date) : (date - now)) / 1000;
		elm.innerHTML = format_timestamp(date) + (diff > 5 ? (' (' + ((now > date) ? '-' : '+') + diff.toString() + 's.)') : '');
	}
};

upcb['TIME'] = TIMEData;

var UPTIMEData = function(data) {
	var elm = document.querySelector('[data-id="UPTIME"]');
	if (elm) {
		elm.innerHTML = format_sec(data);
	}
};

upcb['UPTIME'] = UPTIMEData;

// Real unit-of-measurement suffix per chart (keyed by dashboard.json's
// "name", not "label.class" — the class is shared by unrelated quantities,
// e.g. "volt" covers VRMS, IRMS, POWER_ACTIVE, FREQUENCY, POWER_FACTOR and
// more purely for icon/styling reasons, so it can't tell an Amp reading
// from a Watt one). Replaces the old class-keyed icon glyphs (⌁ etc.) that
// used to live on the (now removed) .chartlabel column.
const UNIT_SUFFIX = {
	ADC0_0: '°C',
	ADC0_1: '°C',
	ADC0_2: '°C',
	ADC0_3: '°C',
	HEAD_TEMP: '°C',
	ADC1_0: 'L',
	ADC1_1: 'V',
	ADC1_2: 'V',
	RPM: 'RPM',
	RSSI: 'dBm',
	VRMS: 'V',
	IRMS: 'A',
	POWER_ACTIVE: 'W',
	POWER_REACTIVE: 'VAR',
	POWER_APPARENT: 'VA',
	FREQUENCY: 'Hz',
	POWER_FACTOR: '',
	ENERGY_IMPORT_ACTIVE: 'kWh',
	ENERGY_EXPORT_ACTIVE: 'kWh',
	ENERGY_IMPORT_REACTIVE: 'kVARh',
	ENERGY_EXPORT_REACTIVE: 'kVARh'
};

// Decimal precision for the human-readable value text (overlay/gauge center
// text only — the plotted/bucketed data array keeps full float precision, so
// the line itself is unaffected). Charts not listed here fall back to plain
// String(value), same as before this map existed.
const VALUE_DECIMALS = {
	VRMS: 0,
	POWER_ACTIVE: 0,
	POWER_REACTIVE: 0,
	POWER_APPARENT: 0,
	ADC0_0: 0,
	ADC0_1: 0,
	ADC0_2: 0,
	ADC0_3: 0,
	HEAD_TEMP: 0,
	IRMS: 1,
	FREQUENCY: 1,
	POWER_FACTOR: 1
};

function formatValue(name, value) {
	const decimals = VALUE_DECIMALS[name];
	if (decimals === undefined) return String(value);
	const num = Number(value);
	if (Number.isNaN(num)) return String(value);
	return num.toFixed(decimals);
}

const themeStyle = getComputedStyle(document.documentElement);
const THEME_GREEN_DIM = themeStyle.getPropertyValue('--green-dim').trim() || '#00c508';
const THEME_RED = themeStyle.getPropertyValue('--red').trim() || '#ff6b6b';
const THEME_BORDER_SOFT = themeStyle.getPropertyValue('--border-soft').trim() || '#0d331a';
const CHART_FONT = '"SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace';

// Draws the current value directly on the canvas, in the top-right corner
// at the same height as the Chart.js legend (the dataset label, e.g.
// "Oil") — replaces the old separate .chartlabel table cell so the reading
// can never cause a layout reflow (it's canvas pixels, not DOM). Plain text,
// no background box.
const valueOverlayPlugin = {
	id: 'valueOverlay',
	afterDraw(chart) {
		const text = chart.$overlayText;
		if (!text) return;
		const { ctx, chartArea } = chart;
		if (!chartArea) return;

		ctx.save();
		ctx.font = 'bold 15px ' + CHART_FONT;
		ctx.textBaseline = 'middle';
		const x = chartArea.right - 8;
		// chart.legend is Chart.js's own layout box for the dataset-label
		// row above chartArea — align the value with that same band instead
		// of sitting below it, inside the plot area. Falls back to the old
		// plot-area placement if the legend is ever disabled.
		const legend = chart.legend;
		const y = (legend && typeof legend.top === 'number' && typeof legend.bottom === 'number')
			? (legend.top + legend.bottom) / 2
			: chartArea.top + 8;

		ctx.fillStyle = THEME_GREEN_DIM;
		ctx.textAlign = 'right';
		ctx.fillText(text, x, y);
		ctx.restore();
	}
};
// Chart.js's own default legend behavior toggles something on click — for
// a line chart that's the whole (single) dataset via Chart.defaults'
// onClick; disabling it there is enough since line has no chart-type-
// specific override. Doughnut/pie are different: Chart.js ships its OWN
// onClick at Chart.overrides.doughnut/pie.plugins.legend (not just
// Chart.defaults), which calls toggleDataVisibility(index) — hiding one
// *slice* (the gauge's "value" portion, index 0) rather than the dataset.
// Chart.js's option resolution checks the type-specific "overrides" before
// ever falling back to the generic "defaults", so the Chart.defaults line
// alone silently never touched doughnut charts at all — found live on
// production (2026-10-02): a real legend click there grayed the whole arc
// and struck through the label, `getDataVisibility(0)` was false while
// Chart.defaults' own onClick was already confirmed a no-op — the doughnut
// override was still firing underneath it. All three disabled the same way
// now, not just the generic one; none of this project's charts use "pie",
// but it's the exact same built-in handler and costs nothing to cover too.
function disableLegendToggle() {}
Chart.defaults.plugins.legend.onClick = disableLegendToggle;
if (Chart.overrides.doughnut) Chart.overrides.doughnut.plugins.legend.onClick = disableLegendToggle;
if (Chart.overrides.pie) Chart.overrides.pie.plugins.legend.onClick = disableLegendToggle;

Chart.register(valueOverlayPlugin);

// Draws a big centered value in the empty space of a semi-circle "gauge"
// doughnut chart (see the "gauge" config field in dashboard.json).
const gaugeCenterTextPlugin = {
	id: 'gaugeCenterText',
	afterDraw(chart) {
		const text = chart.$gaugeText;
		if (!text) return;
		const { ctx, chartArea } = chart;
		if (!chartArea) return;

		// rotation:-90 / circumference:180 draws the arc across the top
		// half only, so the label sits lower, in the empty bottom half.
		const cx = (chartArea.left + chartArea.right) / 2;
		const cy = chartArea.top + (chartArea.bottom - chartArea.top) * 0.78;

		ctx.save();
		ctx.font = 'bold 30px ' + CHART_FONT;
		ctx.fillStyle = chart.$gaugeColor || THEME_GREEN_DIM;
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText(text, cx, cy);
		ctx.restore();
	}
};
Chart.register(gaugeCenterTextPlugin);

function addInputSwitchRow(c) {
	const grid = document.getElementById('inputs');
	const alarmClass = c.type === 'alarm' ? ' alarm' : '';

	let itemHtml = `<div data-id="${c.name}" class="indicator voff${alarmClass}">
		<span class="led"></span>
		<span class="indicator-label">${c.label}</span>
	</div>`;

	grid.insertAdjacentHTML('beforeend', itemHtml);
}

function addSwitchRow(c) {
	const grid = document.getElementById('switches');

	let itemHtml = `<div data-id="${c.name}" class="switch-row voff">
		<span class="switch-label">${c.label}</span>
		<span class="switch-buttons">
			<button data-command="${c.command.off}" class="switch-button boff">OFF</button>
			<button data-command="${c.command.on}" class="switch-button bon">ON</button>
		</span>
	</div>`;

	grid.insertAdjacentHTML('beforeend', itemHtml);
}

function addChartRow(row) {
	const table = document.getElementById('charts');

	let rowHtml = `<tr>`;

	for ( const c of row ) {
		if (c.widget === 'value') {
			// Plain DOM tile, no Chart.js instance — for values where a
			// history line/gauge arc doesn't mean anything (e.g. a
			// monotonically-increasing energy counter). Reuses
			// .chartcanvas-block for the same border/background as every
			// other cell in this grid, so it lines up visually.
			rowHtml += `<td class="chartcell">
				<div class="chartcanvas-block value-tile">
					<div class="value-tile-header">
						<span class="value-tile-swatch"></span>
						<span class="value-tile-label">${c.value_label || c.name}</span>
					</div>
					<div class="value-tile-value" id="${c.name}">&nbsp;</div>
				</div>
			</td>`;
		} else {
			rowHtml += `<td class="chartcell">
				<div class="chartcanvas-block">
					<button type="button" class="chart-toggle-btn" data-toggle="${c.name}" title="Switch arc/line">&#8644;</button>
					<canvas id="${c.name}" width="${c.canvas.width}" height="${c.canvas.height}" class="${c.canvas.class}"></canvas>
				</div>
			</td>`;
		}
	}

	rowHtml += `</tr>`;

	table.insertAdjacentHTML('beforeend', rowHtml);
}

// zones: [{min, color}, ...] sorted highest-min first (see dashboard.json's
// "gauge.zones"). Returns the color of the first zone the value still
// qualifies for, falling back to the lowest zone for anything below all of
// them.
function gaugeColorFor(value, zones) {
	for (const z of zones) {
		if (value >= z.min) return z.color;
	}
	return zones.length ? zones[zones.length - 1].color : THEME_GREEN_DIM;
}

// Per-bucket aggregation for line-chart history points (see dashboard.json's
// per-chart "aggregate" field: "avg"|"last"|"max", default "avg"). Every WS
// update folds into an in-progress bucket instead of becoming its own point;
// only when bucket_ms has elapsed does the bucket turn into one chart point.
// "avg" carries a {sum,count} accumulator, "last"/"max" carry the raw value.
function bucketInit(type, value) {
	return (type === 'avg') ? { sum: value, count: 1 } : value;
}

function bucketFold(type, acc, value) {
	if (type === 'max') return Math.max(acc, value);
	if (type === 'last') return value;
	acc.sum += value;
	acc.count++;
	return acc;
}

function bucketValue(type, acc) {
	if (type === 'avg') return Math.round((acc.sum / acc.count) * 100) / 100;
	return acc;
}

// Per-chart arc/line mode, sticky across reloads (data.default_mode
// otherwise, matching whatever dashboard.json's author actually chose).
const CHART_MODE_PREFIX = 'chartMode:';

function loadChartMode(name, fallback) {
	try {
		return localStorage.getItem(CHART_MODE_PREFIX + name) || fallback;
	} catch (e) {
		return fallback;
	}
}

function saveChartMode(name, mode) {
	try {
		localStorage.setItem(CHART_MODE_PREFIX + name, mode);
	} catch (e) {}
}

function addChartWidget(data) {
	const unit = UNIT_SUFFIX[data.name] || '';
	const unitSuffix = unit ? ' ' + unit : '';

	// Plain value tile (see addChartRow) — no Chart.js instance at all, just
	// text updated straight from WS data via upcb/icb like every other widget.
	if (data.widget === 'value') {
		const el = document.getElementById(data.name);
		const setValue = function(value) {
			el.textContent = formatValue(data.name, value) + unitSuffix;
		};
		upcb[data.name] = setValue;
		icb[data.name] = setValue;
		return;
	}

	// Both representations are authored directly in dashboard.json now (see
	// its "line_config"/"gauge_config"/"gauge" fields) — no runtime
	// derivation, after an early version that derived the missing side on
	// the fly got a temperature chart's gauge max wrong (it reused the line
	// chart's "suggestedMax", a soft axis hint Chart.js auto-expands past,
	// as a hard gauge ceiling — every temp gauge pegged full instantly).
	const gauge = data.gauge;
	const gaugeInfo = { gauge: gauge, config: data.gauge_config };
	const lineConfig = data.line_config;

	let chart_widget = null;
	// Carried across a mode switch so the new representation isn't blank
	// until the next WS update arrives — history itself is NOT carried
	// (switching into line mode always starts its own buffer empty, since
	// gauge mode never kept one to hand off).
	let lastValue = undefined;

	function mountGauge() {
		const { min, max, zones } = gaugeInfo.gauge;

		const setGauge = function(value) {
			lastValue = value;
			const clamped = Math.max(min, Math.min(max, value));
			chart_widget.data.datasets[0].data = [clamped - min, max - clamped];
			chart_widget.data.datasets[0].backgroundColor[0] = gaugeColorFor(clamped, zones);
			chart_widget.$gaugeText = formatValue(data.name, value) + unitSuffix;
			chart_widget.$gaugeColor = chart_widget.data.datasets[0].backgroundColor[0];
			chart_widget.update('none');
		};

		upcb[data.name] = setGauge;
		icb[data.name] = setGauge;
		if (lastValue !== undefined) setGauge(lastValue);
	}

	function mountLine() {
		idxcb[data.name] = 0;

		const aggregate = data.aggregate || 'avg';
		let bucketAcc = null;
		let bucketStart = null;

		function pushPoint(v) {
			idxcb[data.name]++;
			chart_widget.data.labels.push("");
			chart_widget.data.datasets.forEach( (dataset) => {
				dataset.data.push(v);
			});

			if (idxcb[data.name] > max_char_points) {
				chart_widget.data.labels.shift();
				chart_widget.data.datasets.forEach( (dataset) => {
					dataset.data.shift();
				}
				);
			}
		}

		const setLine = function(value) {
			lastValue = value;
			const now = Date.now();

			if (bucketStart === null) {
				bucketStart = now;
				bucketAcc = bucketInit(aggregate, value);
			} else if (now - bucketStart >= bucket_ms) {
				pushPoint(bucketValue(aggregate, bucketAcc));
				bucketStart = now;
				bucketAcc = bucketInit(aggregate, value);
			} else {
				bucketAcc = bucketFold(aggregate, bucketAcc, value);
			}

			// Overlay always shows the latest raw reading, independent of the
			// bucket the history line is currently accumulating.
			chart_widget.$overlayText = formatValue(data.name, value) + unitSuffix;
			chart_widget.update('none');
		};

		upcb[data.name] = setLine;

		icb[data.name] = function(value) {
			for (var i = 0; i < max_char_points; i++) {
				idxcb[data.name]++;
				chart_widget.data.labels.push("");
				chart_widget.data.datasets.forEach( (dataset) => {
						dataset.data.push(value);
				});
			}

			bucketStart = Date.now();
			bucketAcc = bucketInit(aggregate, value);
			setLine(value);
		};

		if (lastValue !== undefined) setLine(lastValue);
	}

	function mount(mode) {
		const cfg = (mode === 'gauge') ? gaugeInfo.config : lineConfig;
		chart_widget = new Chart(document.getElementById(data.name), cfg);
		if (mode === 'gauge') mountGauge(); else mountLine();
	}

	// Default mode is whatever dashboard.json's own "default_mode" says,
	// overridden by a sticky user choice if one was saved.
	let mode = loadChartMode(data.name, data.default_mode);
	mount(mode);

	addEventListener("resize", (e) => {
		chart_widget.resize();
	});

	const toggleBtn = document.querySelector('[data-toggle="' + data.name + '"]');
	if (toggleBtn) {
		toggleBtn.addEventListener('click', function() {
			mode = (mode === 'gauge') ? 'line' : 'gauge';
			chart_widget.destroy();
			mount(mode);
			saveChartMode(data.name, mode);
		});
	}
}

function addCharts(row) {
	if (row.length > 0) {
		addChartRow(row);
		for ( const c of row ) {
			addChartWidget( c );
		}
	}
}

var fetchDashboard = function() {
	fetch('/static/dashboard.json',{method:'GET'}).then(r=>r.json()).then(d=>{
		if (display_charts && d.dashboard && Array.isArray(d.dashboard.charts) && d.dashboard.charts.length > 0) {
			var chart_row = [];

			for ( const c of d.dashboard.charts ) {
				chart_row.push(c);

				if (chart_row.length == charts_in_row) {
					addCharts(chart_row);
					chart_row = [];
				}
			}

			if (chart_row.length > 0) {
				addCharts(chart_row);
			}
		}

		if (d.dashboard && Array.isArray(d.dashboard.switches) && d.dashboard.switches.length > 0) {
			for ( const c of d.dashboard.switches ) {
				addSwitchRow(c);
			}

			const PENDING_TIMEOUT_MS = 5000; // fallback in case the WS confirmation never arrives

			Array.from(document.getElementsByClassName('switch-button')).forEach(b => b.addEventListener('click', function(e) {
				if (!e.target.dataset.command) return;
				conm(e.target.dataset.command);
				const row = e.target.closest('.switch-row');
				if (row) {
					row.classList.add('pending');
					clearTimeout(row._pendingTimeout);
					row._pendingTimeout = setTimeout(() => row.classList.remove('pending'), PENDING_TIMEOUT_MS);
				}
			}));
		}

		if (d.dashboard && Array.isArray(d.dashboard.inputs) && d.dashboard.inputs.length > 0) {
			for ( const c of d.dashboard.inputs ) {
				addInputSwitchRow(c);
			}
		}

		console.log('dashboard:', d);
	});
};

fetchDashboard();
