/* Shared HTML dialog helpers — replaces native alert/confirm/prompt. */
(function (global) {
  "use strict";

  var overlay = null;
  var titleEl = null;
  var bodyEl = null;
  var fieldWrap = null;
  var inputEl = null;
  var okBtn = null;
  var cancelBtn = null;
  var resolveFn = null;

  function ensure() {
    if (overlay) return;
    overlay = document.createElement("div");
    overlay.className = "dlg-overlay";
    overlay.innerHTML =
      '<div class="dlg" role="dialog" aria-modal="true">' +
        '<h2 class="dlg-title"></h2>' +
        '<p class="dlg-body"></p>' +
        '<div class="dlg-field" hidden>' +
          '<label for="dlg-input"></label>' +
          '<input id="dlg-input" type="text" autocomplete="off">' +
        '</div>' +
        '<div class="dlg-actions">' +
          '<button type="button" class="btn dlg-cancel">Cancel</button>' +
          '<button type="button" class="btn dlg-ok">OK</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);
    titleEl = overlay.querySelector(".dlg-title");
    bodyEl = overlay.querySelector(".dlg-body");
    fieldWrap = overlay.querySelector(".dlg-field");
    inputEl = overlay.querySelector("#dlg-input");
    okBtn = overlay.querySelector(".dlg-ok");
    cancelBtn = overlay.querySelector(".dlg-cancel");

    cancelBtn.addEventListener("click", function () { close(null); });
    okBtn.addEventListener("click", function () { accept(); });
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) close(null);
    });
    document.addEventListener("keydown", function (e) {
      if (!overlay || !overlay.classList.contains("open")) return;
      if (e.key === "Escape") { e.preventDefault(); close(null); }
      else if (e.key === "Enter" && !fieldWrap.hidden) { e.preventDefault(); accept(); }
    });
  }

  function accept() {
    if (!fieldWrap.hidden) close(inputEl.value);
    else close(true);
  }

  function close(value) {
    if (!overlay || !overlay.classList.contains("open")) return;
    overlay.classList.remove("open");
    var fn = resolveFn;
    resolveFn = null;
    if (fn) fn(value);
  }

  function open(opts) {
    ensure();
    return new Promise(function (resolve) {
      if (resolveFn) resolveFn(null);
      resolveFn = resolve;
      titleEl.textContent = opts.title || "";
      bodyEl.textContent = opts.message || "";
      bodyEl.style.display = opts.message ? "" : "none";

      var danger = !!opts.danger;
      okBtn.textContent = opts.okLabel || (danger ? "Confirm" : "OK");
      okBtn.className = "btn dlg-ok " + (danger ? "btn-danger" : "btn-primary");
      cancelBtn.textContent = opts.cancelLabel || "Cancel";
      cancelBtn.style.display = opts.hideCancel ? "none" : "";

      if (opts.input != null) {
        fieldWrap.hidden = false;
        var label = fieldWrap.querySelector("label");
        label.textContent = opts.inputLabel || "Value";
        inputEl.type = opts.inputType || "text";
        inputEl.value = opts.input === true ? "" : String(opts.input);
        if (opts.maxLength) inputEl.maxLength = opts.maxLength;
        else inputEl.removeAttribute("maxLength");
        if (opts.step != null) inputEl.step = opts.step;
        else inputEl.removeAttribute("step");
        if (opts.min != null) inputEl.min = opts.min;
        else inputEl.removeAttribute("min");
      } else {
        fieldWrap.hidden = true;
      }

      overlay.classList.add("open");
      if (!fieldWrap.hidden) {
        setTimeout(function () { inputEl.focus(); inputEl.select(); }, 0);
      } else {
        setTimeout(function () { okBtn.focus(); }, 0);
      }
    });
  }

  global.uiDialog = {
    confirm: function (opts) {
      if (typeof opts === "string") opts = { message: opts };
      return open(Object.assign({ title: "Confirm", danger: true }, opts || {}))
        .then(function (v) { return v === true; });
    },
    prompt: function (opts) {
      if (typeof opts === "string") opts = { message: opts };
      opts = opts || {};
      return open(Object.assign({
        title: "Input",
        input: opts.value != null ? opts.value : true,
        inputLabel: opts.inputLabel || "Value",
        inputType: opts.inputType || "text"
      }, opts)).then(function (v) {
        return v === null ? null : v;
      });
    },
    alert: function (opts) {
      if (typeof opts === "string") opts = { message: opts };
      return open(Object.assign({
        title: "Notice",
        hideCancel: true,
        okLabel: "OK",
        danger: false
      }, opts || {})).then(function () { return true; });
    }
  };
})(window);
