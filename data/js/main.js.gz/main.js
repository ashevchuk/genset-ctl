var upcb = {};
var icb = {};
var idxcb = {};

var icbi = false;

var con;

function wsc() {
    // WS now shares port 80 with the HTTP server, at /ws (WebSockets4WebServer,
    // 2026-09-25 - see CLAUDE.md's Web/MQTT interfaces section).
    con = new WebSocket("ws://" + window.location.host + '/ws', ['arduino']);
    con.onclose = function(e) {
	icbi = false;
        setTimeout(function() {
            wsc();
        }, 1000);
    };

    con.onerror = function(e) {
        con.close();
    };

    con.onmessage = function(e) {
        var o = JSON.parse(e.data);

    	for (const p in o) {
        	for (const k in o[p]) {
            	    if (icb[k]) {
                        icb[k](o[p][k]);
                        delete icb[k];
                    }
        	}
    	}


        for (const p in o) {
            for (const k in o[p]) {
                var elms = document.querySelectorAll('[data-id="' + k + '"]');
                if (elms && elms.length) {
                    elms.forEach(function(elm) {
                        if (elm) {
                            if (p === "value") {
                                elm.innerHTML = o[p][k];
                            } else if (p === "switch") {
                                elm.classList.add(o[p][k] ? 'von' : 'voff');
                                elm.classList.remove(o[p][k] ? 'voff' : 'von');
                                // Confirmed by the device — release the click-lock set in charts.js.
                                elm.classList.remove('pending');
                                clearTimeout(elm._pendingTimeout);
                            }
                        }
                    })
                }
                if (upcb[k])
                    upcb[k](o[p][k]);
            }
        }
    };
}

wsc();

var conm = function(m) {
    con.send(m)
};
