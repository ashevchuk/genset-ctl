// Renders <nav> links and (if present on the page) the top #status-cards
// row from dashboard.json's "nav"/"cards" arrays, so a "hidden": true entry
// in that config hides it from every page without editing any HTML file.
// Shared by every data/*.html.gz page (index/wifi-config/fw/journal/fm) —
// unlike main.js/charts.js, which only index.html loads. Wrapped in
// DOMContentLoaded since this file is <script src>'d from <head> on some
// pages, before the <nav>/#status-cards elements below it exist in the DOM.

document.addEventListener('DOMContentLoaded', function() {
	fetch('/static/dashboard.json', {method: 'GET'}).then(r => r.json()).then(d => {
		var dash = d.dashboard || {};

		var navEl = document.querySelector('nav');
		if (navEl && Array.isArray(dash.nav)) {
			navEl.innerHTML = '';
			for (const item of dash.nav) {
				if (item.hidden) continue;
				var a = document.createElement('a');
				a.href = item.href;
				a.textContent = item.label;
				if (window.location.pathname === item.href) {
					a.classList.add('active');
				}
				navEl.appendChild(a);
			}
		}

		var cardsEl = document.getElementById('status-cards');
		if (cardsEl && Array.isArray(dash.cards)) {
			cardsEl.innerHTML = '';
			for (const item of dash.cards) {
				if (item.hidden) continue;
				var card = document.createElement('div');
				card.className = 'card';
				card.innerHTML = '<div class="val" data-id="' + item.id + '">&nbsp;</div>' +
					'<div class="lbl">' + item.label + '</div>';
				cardsEl.appendChild(card);
			}
		}
	});
});
